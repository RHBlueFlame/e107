<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	�William Moffett 2001-2005
|	http://e107.net
|	que@e107.net
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "<i>PenguinBlack v1.1</i> by Psyko Penguin based on Black v2.1");
define("LAN_THEME_2", "Comments are turned off for this item");
define("LAN_THEME_3", "comment: ");
define("LAN_THEME_4", "Read the rest ...");
define("LAN_THEME_5", "Trackbacks: ");


 ?>